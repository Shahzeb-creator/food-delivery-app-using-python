from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Models
class Restaurant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    contact = db.Column(db.String(100), nullable=False)
    menu_items = db.relationship('MenuItem', backref='restaurant', cascade='all, delete')

class MenuItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(300))
    price = db.Column(db.Float, nullable=False)
    restaurant_id = db.Column(db.Integer, db.ForeignKey('restaurant.id'), nullable=False)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    menu_item_id = db.Column(db.Integer, db.ForeignKey('menu_item.id'), nullable=False)
    user_name = db.Column(db.String(100), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    total_price = db.Column(db.Float, nullable=False)

# Initialize and seed database
with app.app_context():
    db.create_all()
    if not Restaurant.query.first():
        r1 = Restaurant(name="Pasta Palace", address="123 Main St", contact="555-1234")
        r2 = Restaurant(name="Burger Barn", address="456 Oak Ave", contact="555-5678")
        r3 = Restaurant(name="Pizza Place", address="789 Elm Rd", contact="555-9012")
        db.session.add_all([r1, r2, r3])
        db.session.flush()

        items = [
            MenuItem(name="Spaghetti", description="Classic spaghetti with marinara", price=10.99, restaurant_id=r1.id),
            MenuItem(name="Ravioli", description="Cheese-filled ravioli", price=12.99, restaurant_id=r1.id),
            MenuItem(name="Classic Burger", description="Beef patty with lettuce and tomato", price=8.99, restaurant_id=r2.id),
            MenuItem(name="Cheeseburger", description="With cheddar cheese", price=9.99, restaurant_id=r2.id),
            MenuItem(name="Pepperoni Pizza", description="Pepperoni and cheese", price=11.99, restaurant_id=r3.id),
        ]
        db.session.add_all(items)
        db.session.commit()

# Routes
@app.route("/", methods=["GET", "POST"])
def homepage():
    if request.method == "POST":
        search_query = request.form.get("search", "").lower()
        restaurants = Restaurant.query.filter(
            (Restaurant.name.ilike(f"%{search_query}%")) | 
            (Restaurant.address.ilike(f"%{search_query}%"))
        ).all()
    else:
        restaurants = Restaurant.query.all()
    return render_template("index.html", restaurants=restaurants)

@app.route("/restaurant/<int:restaurant_id>", methods=["GET", "POST"])
def restaurant_menu(restaurant_id):
    restaurant = Restaurant.query.get_or_404(restaurant_id)
    menu_items = MenuItem.query.filter_by(restaurant_id=restaurant_id).all()
    if request.method == "POST":
        item_id = request.form.get("item_id")
        quantity = int(request.form.get("quantity"))
        user_name = request.form.get("user_name")
        menu_item = MenuItem.query.get_or_404(item_id)
        total_price = menu_item.price * quantity
        order = Order(menu_item_id=item_id, user_name=user_name, quantity=quantity, total_price=total_price)
        db.session.add(order)
        db.session.commit()
        return redirect(url_for("homepage"))
    return render_template("index.html", restaurant=restaurant, menu_items=menu_items)

@app.route("/user/<user_name>")
def user_orders(user_name):
    orders = Order.query.filter_by(user_name=user_name).all()
    return render_template("index.html", user_name=user_name, orders=orders)

if __name__ == "__main__":
    app.run(debug=True)
